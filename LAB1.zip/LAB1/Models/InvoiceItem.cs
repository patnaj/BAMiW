using System;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace LAB1.Models{
    public class InvoiceItemModel
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string ProductName { get; set; }
        public float Price { get; set; }
        public float Amount { get; set; }
        [ForeignKey("Invoice")]
        public int IvoiceID { get; set; }
        public InvoiceModel Ivoice { get; set; }
        
    }
}