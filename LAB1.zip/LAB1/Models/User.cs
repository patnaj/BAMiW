using Microsoft.AspNetCore.Identity;
namespace LAB1.Models{
    public class UserModel : IdentityUser<int>{ }
}